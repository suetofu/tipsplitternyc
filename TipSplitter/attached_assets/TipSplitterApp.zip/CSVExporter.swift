import Foundation

struct CSVExporter {
    static func export(shift: Shift, results: [(employee: ShiftEmployee, digitalTips: Double, cashTips: Double)]) -> String {
        var csv = "Name,Employee ID,Position,Hours Worked,Points,Digital Tips,Cash Tips\n"
        for result in results {
            let e = result.employee
            let name = "\(e.employee.firstName) \(e.employee.lastName)"
            let line = "\(name),\(e.employee.employeeID),\(e.position.title),\(String(format: "%.2f", e.hoursWorked)),\(String(format: "%.2f", e.effectivePoints)),\(String(format: "%.2f", result.digitalTips)),\(String(format: "%.2f", result.cashTips))"
            csv.append(line + "\n")
        }
        return csv
    }
}