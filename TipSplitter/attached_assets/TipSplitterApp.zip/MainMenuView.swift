import SwiftUI

struct MainMenuView: View {
    var body: some View {
        NavigationView {
            List {
                NavigationLink("Create New Shift", destination: Text("Shift Input Placeholder"))
                NavigationLink("Settings", destination: SettingsView())
            }
            .navigationTitle("Tip Splitter")
        }
    }
}