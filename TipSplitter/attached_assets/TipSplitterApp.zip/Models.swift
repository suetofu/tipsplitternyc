import Foundation

struct Employee: Identifiable, Codable, Equatable {
    let id: UUID
    let firstName: String
    let lastName: String
    let employeeID: Int
    var positions: [Position]
}

struct Position: Identifiable, Codable, Hashable {
    let id: UUID
    let title: String
    let defaultPointValue: Double
}

struct Shift: Identifiable {
    let id: UUID
    var date: Date
    var type: String
    var creditCardTips: Double
    var houseTips: Double
    var cashTips: Double
    var employees: [ShiftEmployee]
}

struct ShiftEmployee: Identifiable {
    let id: UUID
    var employee: Employee
    var position: Position
    var pointOverride: Double?
    var clockIn: Date
    var clockOut: Date

    var effectivePoints: Double {
        pointOverride ?? position.defaultPointValue
    }

    var hoursWorked: Double {
        return clockOut.timeIntervalSince(clockIn) / 3600
    }
}