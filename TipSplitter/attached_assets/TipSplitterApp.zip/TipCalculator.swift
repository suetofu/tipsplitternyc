import Foundation

struct TipCalculator {
    static func calculateTips(for shift: Shift) -> [(employee: ShiftEmployee, digitalTips: Double, cashTips: Double)] {
        let digitalTotal = shift.creditCardTips + shift.houseTips
        let totalPoints = shift.employees.reduce(0) { $0 + $1.effectivePoints }
        var results: [(ShiftEmployee, Double, Double)] = []

        for employee in shift.employees {
            let shareRatio = employee.effectivePoints / totalPoints
            let digitalShare = digitalTotal * shareRatio
            let cashShare = shift.cashTips * shareRatio
            results.append((employee, digitalShare, cashShare))
        }
        return results
    }
}