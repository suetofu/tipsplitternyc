import SwiftUI

enum RoundingOption: String, CaseIterable, Identifiable {
    case none = "No Rounding"
    case fifteen = "15 Minutes"
    case thirty = "30 Minutes"
    case fortyFive = "45 Minutes"
    case hour = "Full Hour"

    var id: String { self.rawValue }

    var intervalInMinutes: Double {
        switch self {
        case .none: return 0
        case .fifteen: return 15
        case .thirty: return 30
        case .fortyFive: return 45
        case .hour: return 60
        }
    }
}

struct SettingsView: View {
    @AppStorage("roundingOption") var roundingOption: String = RoundingOption.none.rawValue

    var body: some View {
        Form {
            Section(header: Text("Time Rounding")) {
                Picker("Round Time To:", selection: $roundingOption) {
                    ForEach(RoundingOption.allCases) { option in
                        Text(option.rawValue).tag(option.rawValue)
                    }
                }
            }
        }
        .navigationTitle("App Settings")
    }
}